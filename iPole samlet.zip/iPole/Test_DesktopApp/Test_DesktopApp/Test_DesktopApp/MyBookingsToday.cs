﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Test_DesktopApp
{
    public partial class MyBookingsToday : Form
    {
        public MyBookingsToday()
        {
            InitializeComponent();
            Do_Checked();
        }

        private void buttonLogOut_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form1 login = new Form1();
            login.Show();
        }

        private void MyBookingsToday_Load(object sender, EventArgs e)
        {
            Do_Checked();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            Do_Checked();
        }

        private void Do_Checked()
        {
            button1.Enabled = checkBox1.Checked || checkBox2.Checked || checkBox3.Checked;
            if(checkBox1.CheckState == CheckState.Checked)
            {
                checkBox2.CheckState = CheckState.Checked;
                checkBox3.CheckState = CheckState.Checked;
            }
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Do_Checked();
            MessageBox.Show("You have attended the classes");

        }

        private void Title_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("You have attended Open Gym");
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            Do_Checked();
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            Do_Checked();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MyFutureBookings();
        }

        private void MyFutureBookings()
        {
         
                this.Hide();

                MyFutureBookings nextPage = new MyFutureBookings();
                nextPage.Show();
            
           
        }
    }
}