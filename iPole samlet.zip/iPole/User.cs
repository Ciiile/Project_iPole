﻿using System;
using System.Collections.Generic;


namespace Project_iPole_01

{
    public class User : IComparable
    {
        public string Firstname { get; set; }
        private string Lastname { get; set; }
        private int MemberId { get; set; }
        private string Password { get; set; }
        private bool LoginStatus { get; set; }

        public User(string firstname, string lastname, int memberId, string password, bool loginStatus)
        {
            Firstname = firstname;
            Lastname = lastname;
            MemberId = memberId;
            Password = password;
            LoginStatus = loginStatus;
        }

        private bool VerifyLogin()
        {
            return true;
        }

        public int CompareTo(object obj)
        {
            if (obj == null)
            {
                return 1;
            }
            User otherUser = obj as User;

            if (otherUser == null)
            {
                return this.MemberId.CompareTo(otherUser.MemberId);
            }
            else
            {
                throw new ArgumentException("Object is not a User");
            }
        }
    }
}
