﻿using System;
using System.Collections.Generic;
using Microsoft.VisualBasic.FileIO;

namespace Project_iPole_01.Test_DesktopApp
{
    public class IPoleSystem
    {
        public List<User> AllUsers = new List<User>();

        public void CreateUserList()
        {
            int memberId;

            var path = @"/Users/charlotteguldbaek/Downloads/Bruger.csv";
            using (TextFieldParser csvParser = new TextFieldParser(path))
            {
                csvParser.CommentTokens = new string[] { "#" };
                csvParser.SetDelimiters(new string[] { "," });
                csvParser.HasFieldsEnclosedInQuotes = false;

                csvParser.ReadLine();

                while (!csvParser.EndOfData)
                {
                    string[] fields = csvParser.ReadFields();
                    string firstname = fields[0];
                    string lastname = fields[1];
                    string id = fields[2];
                    string password = fields[3];

                    memberId = Int16.Parse(id);

                    AllUsers.Add(new User(firstname, lastname, memberId, password, false));
                }
            }
        }

        public void PrintUsers()
        {
            foreach (User u in AllUsers)
            {
                Console.WriteLine(u.Firstname);
            }
        }

        public IPoleSystem()
        {
        }
    }
}
