﻿using System;

namespace Project_iPole_01
{


    class Program
    {
        static void Main(string[] args)
        {
            FitnessClass Polelvl1 = new FitnessClass("Pole - level 1", 8, 0, "18:00", "20/03/20", 1);
        }
    }
}
