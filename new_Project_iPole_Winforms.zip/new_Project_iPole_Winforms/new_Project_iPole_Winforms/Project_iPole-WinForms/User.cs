﻿using System;
using System.Collections.Generic;


namespace Project_iPole_01

{
    public class User : IComparable
    {
        private string Firstname { get; set; }
        private string Lastname { get; set; }
        private string MemberId { get; set; }
        private string Password { get; set; }
        private bool LoginStatus { get; set; }

        public User(string firstname, string lastname, string memberId, string password, bool loginStatus)
        {
            Firstname = firstname;
            Lastname = lastname;
            MemberId = memberId;
            Password = password;
            LoginStatus = loginStatus;
        }

        private bool VerifyLogin()
        {
            return true;
        }

        public int CompareTo(object obj)
        {
            if (obj == null)
            {
                return 1;
            }
            User otherUser = obj as User;

            if (otherUser == null)
            {
                return this.MemberId.CompareTo(otherUser.MemberId);
            }
            else
            {
                throw new ArgumentException("Object is not a User");
            }
        }
    }
}
