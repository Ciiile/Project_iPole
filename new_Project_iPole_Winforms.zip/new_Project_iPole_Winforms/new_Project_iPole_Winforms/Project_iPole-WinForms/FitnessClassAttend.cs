﻿namespace Project_iPole_01
{
    class FitnessClassAttend : FitnessClass
    {
        public FitnessClassAttend(string title, int numberOfParticipants, int waitlist, string time, string date, int room) : base(title, numberOfParticipants, waitlist, time, date, room)
        {

        }
    }
}
